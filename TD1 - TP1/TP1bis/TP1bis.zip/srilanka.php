<?php
    $srilanka=array("Negombo"=>array("lat"=>7.200796799999999,"long"=>79.87367540000002,"pop"=>121701),
                    "Anuradhapura"=>array("lat"=>8.311351799999997,"long"=>80.40365079999992,"pop"=>50595),
                    "Trincomalee"=>array("lat"=>8.6438171,"long"=>81.0754657,"pop"=>99135));
?>