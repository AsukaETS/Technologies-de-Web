<?php include "utile.php"; ?>
<?php include "connexion.php"; ?>

<!DOCTYPE html>
<html>
 <head>
	<meta charset="utf-8" />
  	<link href="style/style.css" rel="stylesheet" type="text/css" />
	<title>SiteWebShop</title>

</head>
<body>
    <?php require "header.php"; ?>
	<section>
        <header><h1>Mon Panier</h1></header>
        <div id="empty-cart">
            <img src="images/poubelle.png" alt="Poubelle" />
            <p>Votre panier est vide</p>
        </div>
	</section>
    <?php require "footer.php"; ?>
</body>
</html>