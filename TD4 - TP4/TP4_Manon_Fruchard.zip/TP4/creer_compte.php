<?php include "utile.php"; ?>
<?php include "connexion.php"; ?>

<?php
    if(isset($_POST['mail']) && ($_POST['mdp']) && ($_POST['nom']) && ($_POST['prenom']) && ($_POST['adresse']) && ($_POST['cp']) && ($_POST['ville']) && ($_POST['pays']) && ($_POST['tel']))
    {
        $mail = $_POST['mail'] ;
        $civ = $_POST['civ'] ;
        $mdp = $_POST['mdp'] ;
        $nom = $_POST['nom'] ;
        $prenom = $_POST['prenom'] ;
        $adresse = addslashes($_POST['adresse']) ;
        $cp = $_POST['cp'] ;
        $ville = $_POST['ville'] ;
        $pays = $_POST['pays'] ;
        $tel = $_POST['tel'] ;
        
        $sql='SELECT COUNT(email) FROM client WHERE email="$mail"';
        $rep=$connexion->query($sql);
        $count=$rep->fetchColumn() ;
        
        if ($count == 0) {
    $ins = "INSERT INTO client(email, mot_de_passe, civilite, nom, prenom, adresse, code_postal, ville, pays, telephone) VALUES ($mail,$mdp,$civ,$nom,$prenom,$adresse,$cp,$ville,$pays,$tel)" ;
    $connexion->exec($ins) ;
    echo "<p>Votre compte a bien été enregistré, un mail de confirmation vous a été envoyé </p>" ;
    }
        else {
            echo "<p> Désolé mais il semblerait cet e-mail soit déjà pris.</p>" ;
        } 
    }
else {
    $chaine = " " ;
}



?>

<!DOCTYPE html>
<html>
 <head>
	<meta charset="utf-8" />
  	<link href="style/style.css" rel="stylesheet" type="text/css" />
	<title>SiteWebShop</title>
</head>
<body>
<!-- DEBUT de la page -->
    <?php require "header.php"; ?>
	<section>
				<header><h1>Créer un compte</h1></header>
              <form id="creer-compte" method="POST" action="creer_compte.php">
    <fieldset id="creer-compte"> <p>
        <label for="edtmail" id="idmail">E-mail</label>
        <input type="text" id="edtmail" name="mail" required /> </p><p>
        <label for="edtciv" id = "idciv"> Civilité </label>
        <select name="civ"><option>Mr</option><option>Mme</option><option>Mlle</option></select></p><p>
        <label for="edtmdp" id="idmdp">Mot de Passe</label>
        <input type="text" id="edtmdp" name="mdp" required  /></p><p>
        <label for="edtnom" id="idnom">Nom</label>
        <input type="text" id="edtnom" name="nom" required />  </p><p>
        <label for="edtprenom" id="idprenom">Prénom</label>
        <input type="text" id="edtprenom" name="prenom" required /> </p><p>
        <label for="edtadresse" id="idadresse">Adresse</label>
        <input type="text" id="edtadresse" name="adresse" required /> </p><p>
        <label for="edtcp" id="idcp">Code Postal</label>
        <input type="text" id="edtcp" name="cp" required /> </p><p>
        <label for="edtVille" id="idVille">Ville</label>
        <input type="text" id="edtville" name="ville" required /> </p><p>
        <label for="edtpays" id="idpays">Pays</label>
        <input type="text" id="edtpays" name="pays" required /> </p><p>
        <label for="edttel" id="idVtel">Téléphone</label>
        <input type="text" id="edttel" name="tel" required /> </p>
    </fieldset>
    <p class="submit">
      <input type="submit" id="btnSubmit" value="Envoyer" name="send" />    
    </p>
      </form> 
	</section>
    <?php require "footer.php"; ?>
</body>
</html>