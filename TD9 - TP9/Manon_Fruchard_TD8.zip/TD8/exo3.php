<?php 

    $nom = $_GET["nom"] ;
    $prenom = $_GET["prenom"] ;
        
    echo "Bonjour $nom $prenom" ;

?>