<?php
	if($_POST["ok"]==true)
	{
		echo '{"personnes":[{"nom": "Lerdorf", "prenom": "Rasmus"}, {"nom": "Gutmans", "prenom": "Andi"}, {"nom": "Suraski", "prenom": "Zeev"}]}';
	}
?>