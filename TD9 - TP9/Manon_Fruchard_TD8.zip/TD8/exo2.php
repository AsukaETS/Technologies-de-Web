<?php 

    $nom = "Fruchard" ;
    $prenom = "Manon" ;
        
    echo "Bonjour $nom $prenom" ;

?>